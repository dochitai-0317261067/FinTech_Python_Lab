#bai3_ecommercy.py

print("~~~ GIỎ HÀNG SỐ CỦA BẠN ~~~")
# Nhập giá trị 3 sản phẩm
item1 =float(input("Nhập giá sản phẩm 1: "))
item2 =float(input("Nhập giá sản phẩm 2: "))
item3 =float(input("Nhập giá sản phẩm 3: "))

discount_rate = float(input("Nhập % mã giảm giá (VD:10 cho 10%): ")) /100
VAT_RATE = 0.08 #Thuế VAT = 8%

# Tính Toán các thành phần
subtotal = item1 + item2 + item3
discount_ammout = subtotal * discount_rate
price_after_discount = subtotal - discount_ammout
vat_ammout = price_after_discount * VAT_RATE
final_total = price_after_discount + vat_ammout
# Hiển thị hóa đơn
print("\n~~~ HÓA ĐƠN ĐIỆN TỬ ~~~")
print(f"Tạm tính         : {round(subtotal):,.0f}VND")
print(f"Giảm giá         : -{round(discount_ammout):,.0f}VND")
print(f"Thuế VAT         : {round(vat_ammout):,.0f}VND")
print("~" * 25)
print(f"TỔNG THANH TOÁN: {round(final_total):,.0f}VND")
